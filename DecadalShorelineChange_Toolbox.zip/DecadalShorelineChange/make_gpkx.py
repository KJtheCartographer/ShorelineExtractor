# -*- coding: utf-8 -*-
"""
Build a geoprocessing package (.gpkx) for the Decadal Shoreline Change toolbox.

ArcGIS Pro can only package a tool after it has run successfully, so this
script runs all four tools on a small sample area and then packages those
results with arcpy.management.PackageResult.

HOW TO RUN
  1. Edit the CONFIG block below so it points at SMALL sample data. A single
     NAIP tile or a clipped subset is plenty, since the package carries
     copies of the input data along with it.
  2. In ArcGIS Pro, open the Python window or a Notebook and run:
         exec(open(r"C:\\path\\to\\make_gpkx.py").read())
     Or from the Python Command Prompt that ships with Pro:
         propy make_gpkx.py
  3. Upload the resulting .gpkx to ArcGIS Online / Portal. You can do that in
     the browser (Content > New item) or set UPLOAD = True below to use your
     signed-in Pro account.
"""

import os
import datetime
import arcpy

# =============================================================================
# CONFIG: edit these
# =============================================================================
HERE = os.path.dirname(os.path.abspath(__file__)) if "__file__" in globals() else os.getcwd()

TOOLBOX = os.path.join(HERE, "DecadalShorelineChange.pyt")
WORKSPACE = os.path.join(HERE, "ShorelineSample.gdb")       # created if missing

IMAGERY_DATE1 = r"C:\data\naip\sample_2016.tif"              # baseline imagery
IMAGERY_DATE2 = r"C:\data\naip\sample_2025.tif"              # comparison imagery
DATE1 = datetime.date(2016, 4, 12)
DATE2 = datetime.date(2025, 4, 12)

REFERENCE_SHORELINE = r"C:\data\sample.gdb\LLM_Shoreline_Ref"  # polyline, or None
ANALYSIS_AREA = None                                            # polygon, or None

METHOD = "NDWI (Green/NIR)"      # or "Brightness (RGB only)"
THRESHOLD = 0.0                  # NDWI > 0   |   brightness < 30

# Restoration overlay layers. Leave empty to skip Tool 4 (it won't be packaged).
OVERLAY_LAYERS = [
    # r"C:\data\sample.gdb\Public_Lands",
    # r"C:\data\sample.gdb\Seagrass_Habitat",
    # r"C:\data\sample.gdb\Restoration_Projects",
]

OUTPUT_GPKX = os.path.join(HERE, "DecadalShorelineChange.gpkx")
EXTRA_FILES = [os.path.join(HERE, "INSTALL.md")]

SUMMARY = (
    "Extracts shorelines from two dates of aerial/satellite imagery (NDWI or RGB "
    "brightness), measures erosion/accretion along 50 m transects, reports "
    "annualized change rates (m/yr), and flags transects that intersect "
    "restoration planning layers."
)
TAGS = "shoreline change, erosion, accretion, NAIP, NDWI, transects, coastal resilience, restoration"

UPLOAD = False                   # True = share to the portal Pro is signed in to
UPLOAD_PUBLIC = False

# =============================================================================


def main():
    arcpy.env.overwriteOutput = True

    if not os.path.exists(TOOLBOX):
        raise FileNotFoundError(f"Toolbox not found: {TOOLBOX}")
    for path in [IMAGERY_DATE1, IMAGERY_DATE2] + ([REFERENCE_SHORELINE] if REFERENCE_SHORELINE else []):
        if not arcpy.Exists(path):
            raise FileNotFoundError(f"Input not found: {path}")
    if arcpy.CheckExtension("Spatial") != "Available":
        raise RuntimeError("Spatial Analyst is required for Extract Shoreline.")
    arcpy.CheckOutExtension("Spatial")

    if not arcpy.Exists(WORKSPACE):
        arcpy.management.CreateFileGDB(os.path.dirname(WORKSPACE), os.path.basename(WORKSPACE))

    arcpy.ImportToolbox(TOOLBOX)   # alias: shorelinechange

    def out(name):
        return os.path.join(WORKSPACE, name)

    d1 = DATE1.strftime("%m/%d/%Y")
    d2 = DATE2.strftime("%m/%d/%Y")
    results = []

    print("1/4 Extracting baseline shoreline...")
    results.append(arcpy.shorelinechange.ExtractShoreline(
        in_raster=IMAGERY_DATE1,
        out_shoreline=out(f"Shoreline_{DATE1.year}"),
        method=METHOD,
        threshold=THRESHOLD,
        reference_line=REFERENCE_SHORELINE or "",
        analysis_area=ANALYSIS_AREA or "",
        out_water=out(f"Water_{DATE1.year}"),
    ))

    print("    Extracting comparison shoreline...")
    results.append(arcpy.shorelinechange.ExtractShoreline(
        in_raster=IMAGERY_DATE2,
        out_shoreline=out(f"Shoreline_{DATE2.year}"),
        method=METHOD,
        threshold=THRESHOLD,
        reference_line=REFERENCE_SHORELINE or "",
        analysis_area=ANALYSIS_AREA or "",
        out_water=out(f"Water_{DATE2.year}"),
    ))

    print("2/4 Generating transects...")
    results.append(arcpy.shorelinechange.GenerateTransects(
        baseline=out(f"Shoreline_{DATE1.year}"),
        out_transects=out(f"Transects_{DATE1.year}"),
        spacing_m=50,
        length_m=300,
    ))

    print("3/4 Calculating shoreline change...")
    change_fc = out(f"Change_{DATE1.year}_{DATE2.year}")
    results.append(arcpy.shorelinechange.CalculateShorelineChange(
        transects=out(f"Transects_{DATE1.year}"),
        baseline_water=out(f"Water_{DATE1.year}"),
        comparison=out(f"Shoreline_{DATE2.year}"),
        date1=d1,
        date2=d2,
        out_fc=change_fc,
        stable_m=1.0,
        out_vectors=out(f"ChangeVectors_{DATE1.year}_{DATE2.year}"),
    ))

    if OVERLAY_LAYERS:
        print("4/4 Running restoration overlay...")
        results.append(arcpy.shorelinechange.RestorationOverlay(
            change_fc=change_fc,
            overlays=OVERLAY_LAYERS,
            out_fc=out("Priority_Transects"),
            search_m=0,
            erosion_threshold=0.5,
        ))
    else:
        print("4/4 Skipped (no overlay layers). Restoration Overlay won't be in the package.")

    extras = [f for f in EXTRA_FILES if os.path.exists(f)]

    print(f"Packaging {len(results)} results -> {OUTPUT_GPKX}")
    arcpy.management.PackageResult(
        in_result=results,
        output_file=OUTPUT_GPKX,
        convert_data="CONVERT",
        additional_files=extras,
        summary=SUMMARY,
        tags=TAGS,
    )
    print("Package created.")

    if UPLOAD:
        print("Uploading to the portal Pro is signed in to...")
        arcpy.management.SharePackage(
            in_package=OUTPUT_GPKX,
            username="",
            password="",
            summary=SUMMARY,
            tags=TAGS,
            public="EVERYBODY" if UPLOAD_PUBLIC else "MYGROUPS",
        )
        print("Upload complete. Check My Content in ArcGIS Online.")

    print("Done.")


main()
