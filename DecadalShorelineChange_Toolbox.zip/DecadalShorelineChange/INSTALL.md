# Decadal Shoreline Change Tool: install and packaging

## What's in this folder

- `DecadalShorelineChange.pyt`: the ArcGIS Pro Python toolbox (four tools)
- `make_gpkx.py`: builds a geoprocessing package (.gpkx) from sample runs
- `INSTALL.md`: this file

## Option A: use the toolbox directly (simplest)

1. Unzip this folder anywhere.
2. In ArcGIS Pro, open Catalog, right-click **Toolboxes**, choose **Add Toolbox**, and pick `DecadalShorelineChange.pyt`.
3. Run the tools in order: 1. Extract Shoreline (once per date), 2. Generate Transects, 3. Calculate Shoreline Change, 4. Restoration Overlay.

You need Spatial Analyst for Tool 1. Every input has to be in a projected coordinate system.

## Option B: build a geoprocessing package (.gpkx)

ArcGIS Pro only packages a tool after it has run successfully, so the package gets built from real runs.

**Scripted:** open `make_gpkx.py`, point the CONFIG block at a small sample area, and run it from Pro's Python window or with `propy make_gpkx.py`.

**By hand in Pro:**
1. Run each tool once on small sample data.
2. Open **History** (Analysis tab), select the successful runs, then right-click and choose **Share As > Share Geoprocessing Package**.
3. Fill in the summary and tags. Then either check **Upload package to online account** or save it to a file.
4. Click **Analyze**, fix any errors it reports, and click **Package**.

## Uploading to ArcGIS Online

Upload the `.gpkx` through **Content > New item**, or use the upload option when you package. It shows up as a geoprocessing package item. Other people download it and open it in Pro, and the tools come with it.

A .gpkx doesn't run in a browser. Running the tool online would mean publishing it as a web tool on ArcGIS Enterprise.

## Notes

- Keep the sample data small, because the package includes copies of the inputs.
- Sign convention matches USGS DSAS: negative = erosion, positive = accretion.
- Defaults: 300 m analysis buffer, 50 m transect spacing, 300 m transect length (centered on the shoreline), 1 m stable threshold.
